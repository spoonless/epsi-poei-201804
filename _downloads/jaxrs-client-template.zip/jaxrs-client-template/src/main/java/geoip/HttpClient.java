package geoip;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.filter.LoggingFilter;

/**
 * Exemple d'utilisation de l'API Web de freegeoip (http://freegeoip.net/)
 */
public class HttpClient {

	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		client.register(new LoggingFilter());

		// TODO à implémenter
	}
}
